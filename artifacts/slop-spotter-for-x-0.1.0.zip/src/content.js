(function startContentScript(root) {
  "use strict";

  const api = root.SlopSpotter;
  if (!api?.detectSlop || !api?.parsePost || !api?.recordObservation) {
    return;
  }

  let settings;
  let observer;
  let scanScheduled = false;
  let generation = 0;
  let analyzedPosts = new WeakMap();

  function hasVisibleSuggestion(handle, exceptArticle) {
    return [...root.document.querySelectorAll("[data-slop-spotter-host]")].some(
      (host) =>
        host.dataset.slopSpotterSuggestion === "true" &&
        host.dataset.slopSpotterHandle === handle.toLowerCase() &&
        !exceptArticle?.contains(host)
    );
  }

  function callbacksFor(parsed) {
    return {
      onBlock() {
        try {
          api.openBlockHandoff(parsed.handle);
          api.snoozeAccount(parsed.handle, 24 * 60 * 60 * 1000).catch(() => undefined);
        } catch {
          api.showHandoffStatus({
            state: "error",
            handle: parsed.handle,
            message: "Could not open a safe X profile URL for this account."
          });
        }
      },
      onSnooze() {
        return api.snoozeAccount(parsed.handle, 7 * 24 * 60 * 60 * 1000);
      },
      onIgnore() {
        return api.ignoreAccount(parsed.handle);
      }
    };
  }

  function mountFinding(article, payload, account) {
    const shouldSuggest =
      account.shouldSuggest && !hasVisibleSuggestion(payload.parsed.handle, article);
    api.mountPostAnnotation(
      article,
      {
        ...payload,
        account: { ...account, shouldSuggest }
      },
      callbacksFor(payload.parsed)
    );
  }

  function placeEligibleSuggestion(handle, account) {
    if (!account.shouldSuggest || hasVisibleSuggestion(handle)) {
      return;
    }
    for (const article of api.findPosts(root.document)) {
      const payload = analyzedPosts.get(article);
      if (
        payload?.detection.isSlop &&
        payload.parsed.handle.toLowerCase() === handle.toLowerCase()
      ) {
        mountFinding(article, payload, account);
        return;
      }
    }
  }

  function scheduleScan() {
    if (scanScheduled || !settings?.enabled) {
      return;
    }
    scanScheduled = true;
    const run = () => {
      scanScheduled = false;
      scanVisiblePosts();
    };
    if (typeof root.requestIdleCallback === "function") {
      root.requestIdleCallback(run, { timeout: 500 });
    } else {
      root.setTimeout(run, 80);
    }
  }

  async function processPost(article, expectedGeneration) {
    const alreadyProcessed =
      article.dataset.slopSpotterProcessed === String(expectedGeneration);
    const flaggedBefore =
      article.dataset.slopSpotterFlagged === String(expectedGeneration);
    const annotationPresent = article.querySelector("[data-slop-spotter-host]");
    if (
      (alreadyProcessed && (!flaggedBefore || annotationPresent)) ||
      article.dataset.slopSpotterPending === String(expectedGeneration)
    ) {
      return;
    }
    article.dataset.slopSpotterPending = String(expectedGeneration);

    try {
      const parsed = api.parsePost(article);
      if (!parsed || expectedGeneration !== generation || !settings?.enabled) {
        return;
      }

      const detection = api.detectSlop(parsed.text, {
        sensitivity: settings.sensitivity
      });
      const fingerprint = await api.fingerprintPost(
        parsed.handle,
        parsed.statusId,
        parsed.text
      );
      const account = await api.recordObservation({
        handle: parsed.handle,
        fingerprint,
        flagged: detection.isSlop,
        families: detection.families,
        at: Date.now()
      });

      if (expectedGeneration !== generation || !settings?.enabled) {
        return;
      }

      if (detection.isSlop) {
        const payload = { detection, parsed };
        analyzedPosts.set(article, payload);
        article.dataset.slopSpotterFlagged = String(expectedGeneration);
        mountFinding(article, payload, account);
      } else {
        delete article.dataset.slopSpotterFlagged;
      }
      placeEligibleSuggestion(parsed.handle, account);
      article.dataset.slopSpotterProcessed = String(expectedGeneration);
    } finally {
      delete article.dataset.slopSpotterPending;
    }
  }

  function scanVisiblePosts() {
    const currentGeneration = generation;
    api.findPosts(root.document).forEach((article) => {
      processPost(article, currentGeneration).catch(() => {
        delete article.dataset.slopSpotterPending;
      });
    });
  }

  function startObserver() {
    observer?.disconnect();
    observer = new MutationObserver((mutations) => {
      if (mutations.some((mutation) => mutation.addedNodes.length > 0)) {
        scheduleScan();
      }
    });
    observer.observe(root.document.documentElement, { childList: true, subtree: true });
    scheduleScan();
  }

  function resetForSettings(nextSettings) {
    settings = nextSettings;
    generation += 1;
    analyzedPosts = new WeakMap();
    api.removeAllAnnotations();
    api.findPosts(root.document).forEach((article) => {
      delete article.dataset.slopSpotterProcessed;
      delete article.dataset.slopSpotterPending;
      delete article.dataset.slopSpotterFlagged;
    });

    if (settings.enabled) {
      startObserver();
    } else {
      observer?.disconnect();
    }
  }

  async function main() {
    await api.init();
    api.handleBlockHandoff(api.showHandoffStatus).catch(() => {
      api.showHandoffStatus({
        state: "manual",
        message: "The automatic handoff failed. Use the profile’s ••• menu to block manually."
      });
    });

    settings = await api.getSettings();
    if (settings.enabled) {
      startObserver();
    }

    api.onStateChanged((state) => {
      const next = state.settings;
      if (
        next.enabled !== settings.enabled ||
        next.sensitivity !== settings.sensitivity ||
        next.showBlockSuggestions !== settings.showBlockSuggestions
      ) {
        resetForSettings(next);
      } else {
        settings = next;
      }
    });
  }

  main().catch(() => undefined);
})(globalThis);

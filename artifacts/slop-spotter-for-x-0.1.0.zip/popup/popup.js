(async function setupPopup() {
  "use strict";

  const api = globalThis.SlopSpotter;
  const enabled = document.querySelector("#enabled");
  const sensitivity = document.querySelector("#sensitivity");
  const suggestions = document.querySelector("#showBlockSuggestions");
  const status = document.querySelector("#status");
  const stats = document.querySelector("#stats");

  async function save(patch) {
    status.textContent = "Saving…";
    await api.updateSettings(patch);
    status.textContent = "Saved. Open X tabs update automatically.";
  }

  await api.init();
  const settings = await api.getSettings();
  const dashboard = await api.getDashboard();
  enabled.checked = settings.enabled;
  sensitivity.value = settings.sensitivity;
  suggestions.checked = settings.showBlockSuggestions;
  stats.textContent = `${dashboard.flaggedPosts} flagged of ${dashboard.observedPosts} locally observed posts.`;

  enabled.addEventListener("change", () => save({ enabled: enabled.checked }));
  sensitivity.addEventListener("change", () =>
    save({ sensitivity: sensitivity.value })
  );
  suggestions.addEventListener("change", () =>
    save({ showBlockSuggestions: suggestions.checked })
  );
  document.querySelector("#options").addEventListener("click", () => {
    chrome.runtime.openOptionsPage();
  });
})();
